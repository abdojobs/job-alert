﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Net.Mail;

namespace JobAlert
{
    public class JobAlert
    {
        private string stringJobName = "SELECT [sJOB].[name] AS [JobName] FROM [msdb].[dbo].[sysjobs] AS [sJOB] Where [sJOB].[name] like 'REP%' and [sJOB].[name] not like '%ORI' ORDER BY [JobName]";

        public static StringBuilder LoadDataTxtStringBuilder(string nameTXT)
        {
            StringBuilder sb = new StringBuilder();
            string fileName = nameTXT;
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamReader sr = new StreamReader(fullPathFile))
            {
                string[] myText = sr.ReadToEnd().Split(new string[] { "\r\n" }, StringSplitOptions.None);
                for (int i = 0; i < myText.Length; i++)
                {
                    sb.AppendLine(myText[i]);
                }
                sr.Close();
            }

            return sb;
        }

        public static Collection<string> LoadDataTxtCollection(string nameTXT)
        {
            Collection<string> collString = new Collection<string>();
            string fileName = nameTXT;
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamReader sr = new StreamReader(fullPathFile))
            {
                string[] myText = sr.ReadToEnd().Split(new string[] { "\r\n" }, StringSplitOptions.None);
                for (int i = 0; i < myText.Length; i++)
                {
                    if (!string.IsNullOrEmpty(myText[i]))
                    {
                        collString.Add(myText[i]);
                    }
                }
                sr.Close();
            }

            return collString;
        }

        public static string LoadDataTxtString(string nameTXT)
        {
            string myText = string.Empty;
            string fileName = nameTXT;
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamReader sr = new StreamReader(fullPathFile))
            {
                myText = sr.ReadToEnd();
                sr.Close();
            }

            return myText;
        }

        public static string[] LoadDataTxtString(string nameTXT, string spliter)
        {
            string[] myText = null;
            string fileName = nameTXT;
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamReader sr = new StreamReader(fullPathFile))
            {
                myText = sr.ReadToEnd().Split(new string[] { spliter }, StringSplitOptions.None);
                sr.Close();
            }

            return myText;
        }

        public static void SaveDataTxt(string nameTXT, string data)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, nameTXT);
            using (StreamWriter sw = new StreamWriter(fullPathFile))
            {
                sw.Write(data);
                sw.Close();
            }
        }

        public static void SaveDataTxt(string nameTXT, string data, Collection<string> collData)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, nameTXT);
            using (StreamWriter sw = new StreamWriter(fullPathFile))
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < collData.Count; i++)
                {
                    sb.AppendLine(collData[i].ToString());
                }
                sb.AppendLine(data);
                sw.WriteLine(sb.ToString());
                sw.Close();
            }
        }

        public static string GenerateSpaci(string currentPosisi)
        {
            string Result = string.Empty;
            string zero = string.Empty;

            try
            {

                for (int i = 0; i < 32 - currentPosisi.Length; i++)
                {
                    zero += " ";
                }

                Result = zero;
            }
            catch (Exception)
            {
                Result = string.Empty;
            }

            return Result;
        }

        public static Collection<string> GetJobName()
        {
            Collection<string> collJobName = new Collection<string>();
            string fileName = "JobName.txt";

            string[] myText = LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {
                    collJobName.Add(myText[i]);
                }
            }

            return collJobName;
        }

        public static Collection<string> GetJobName(string stringJobName)
        {
            Collection<string> collJobName = new Collection<string>();
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = LoadConnectionString();
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;
            cmd.CommandText = stringJobName;
            cmd.CommandType = CommandType.Text;
            cmd.Connection = conn;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    collJobName.Add(reader["JobName"].ToString());
                }
            }
            catch
            {
                collJobName = new Collection<string>();
            }
            finally
            {
                conn.Close();
            }

            return collJobName;
        }

        public static string LoadConnectionString()
        {
            string connString = string.Empty;
            string fileName = "ConnectionText.txt";
            Collection<string> collData = LoadDataTxtCollection(fileName);
            if (collData[1].Equals("SQL Server Authentication"))
            {
                connString = collData[4];
            }
            else
            {
                connString = collData[2];
            }

            return connString;
        }

        public static void SendEmail(Collection<GlobalClass> collGlobalClass)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LoadDataTxtStringBuilder("Note Header.txt").ToString());
            sb.AppendLine("Tanggal Saat Ini" + GenerateSpaci("Tanggal Saat Ini") + ":   " + DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss"));
            sb.AppendLine("Job Name" + GenerateSpaci("Job Name") + "|    Step Name" + GenerateSpaci("Step Name") + "|   Message");
            sb.AppendLine("-------------------------------------------------------------------------------");
            for (int i = 0; i < collGlobalClass.Count; i++)
            {
                sb.AppendLine(collGlobalClass[i].Column1.ToUpper() + "" + GenerateSpaci(collGlobalClass[i].Column1) + "|    " + collGlobalClass[i].Column2 + "" + GenerateSpaci(collGlobalClass[i].Column2) + "|  " + collGlobalClass[i].Column3);
                sb.AppendLine("-------------------------------------------------------------------------------");
            }
            sb.AppendLine(string.Empty);
            sb.AppendLine(string.Empty);
            sb.AppendLine(LoadDataTxtStringBuilder("NoteFooter.txt").ToString());

            MailMessage msg = new MailMessage();
            SmtpClient mailObj = new SmtpClient(LoadDataTxtStringBuilder("EmailSetting.txt").ToString().Split(new string[] { "\r\n" }, StringSplitOptions.None)[0]);
            msg.From = new MailAddress(LoadDataTxtStringBuilder("FromText.txt").ToString().Split(new string[] { "\r\n" }, StringSplitOptions.None)[0]);

            //CC------------------------------------------------------------- 
            Collection<MailAddress> collCC = new JobAlert().LoadCCText();
            //TO-------------------------------------------------------------
            Collection<MailAddress> collTo = new JobAlert().LoadEmailTo(sb.ToString());

            //-------------------------------------------------------------
            for (int i = 0; i < collTo.Count; i++)
            {
                msg.To.Add(collTo[i]);
            }

            for (int i = 0; i < collCC.Count; i++)
            {
                msg.CC.Add(collCC[i]);
            }

            msg.IsBodyHtml = false;

            msg.Body = sb.ToString();
            msg.Subject = LoadDataTxtStringBuilder("SubjectText.txt").ToString().Split(new string[] { "\r\n" }, StringSplitOptions.None)[0];
            msg.Priority = MailPriority.High;
            mailObj.Send(msg);
        }

        private Collection<MailAddress> LoadEmailTo(string containsData)
        {
            Collection<MailAddress> collTo = new Collection<MailAddress>();

            ///Load from mapping

            string fileName = "MappingTo.txt";
            string[] myText = LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {
                    string[] myMapping = myText[i].Split('-');
                    for (int j = 1; j < myMapping.Length; j++)
                    {
                        if (!string.IsNullOrEmpty(myMapping[j]))
                        {
                            if (containsData.Contains(myMapping[j]))
                            {
                                collTo.Add(new MailAddress(myMapping[0]));
                            }
                        }
                    }
                }
            }


            ///Load from To
            ///jika mappingan tidak ada maka baru ambil dari To
            if (collTo.Count == 0)
            {
                fileName = "ToText.txt";
                myText = LoadDataTxtString(fileName, "\r\n");
                for (int i = 0; i < myText.Length; i++)
                {
                    if (!string.IsNullOrEmpty(myText[i]))
                    {
                        collTo.Add(new MailAddress(myText[i]));
                    }
                }

            }

            return collTo;
        }

        private Collection<MailAddress> LoadCCText()
        {
            Collection<MailAddress> collCC = new Collection<MailAddress>();
            string fileName = "CCText.txt";
            string[] myText = LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {
                    collCC.Add(new MailAddress(myText[i]));
                }
            }

            return collCC;
        }

        public static Collection<string> LoadExceptionText()
        {
            Collection<string> collString = new Collection<string>();
            string fileName = "Exception.txt";

            string[] myText = LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {
                    collString.Add(myText[i]);
                }
            }

            return collString;
        }

        public static void PopulateJobAlert()
        {

            Collection<GlobalClass> collGlobalClass = new Collection<GlobalClass>();
            string sqlData = string.Empty;
            Collection<string> collJobName = GetJobName();//GetJobName(stringJobName);
            for (int i = 0; i < collJobName.Count; i++)
            {
                sqlData = "exec msdb.dbo.sp_help_jobhistory @job_name = '" + collJobName[i] + "' " +
                             ", @run_status = 0 " +
                             ", @start_run_date = " + DateTime.Now.ToString("yyyyMMdd") +
                             ", @start_run_time = " + DateTime.Now.AddHours(-2).ToString("HHmmss") +
                             ", @end_run_time = " + DateTime.Now.ToString("HHmmss") +
                             ", @mode = 'full' ";

                Collection<GlobalClass> collGlobal1 = new JobAlert().PopulateJobMessage(sqlData);
                for (int j = 0; j < collGlobal1.Count; j++)
                {
                    collGlobalClass.Add(collGlobal1[j]);
                }
            }

            if (collGlobalClass.Count > 0)
            {
                SendEmail(collGlobalClass);
            }
        }

        private Collection<GlobalClass> PopulateJobMessage(string sqlData)
        {
            Collection<GlobalClass> collGlobalClass = new Collection<GlobalClass>();
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = LoadConnectionString();
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;
            cmd.CommandText = sqlData;
            cmd.CommandType = CommandType.Text;
            cmd.Connection = conn;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    for (int i = 0; i < collGlobalClass.Count; i++)
                    {
                        if (collGlobalClass[i].Column2.Contains(reader[4].ToString()))
                        {
                            goto nextloop;
                        }
                    }
                    GlobalClass globalClass = new GlobalClass();
                    Collection<string> collString = LoadExceptionText();
                    bool isContains = true;
                    for (int i = 0; i < collString.Count; i++)
                    {
                        if (reader[7].ToString().Contains(collString[i]))
                        {
                            isContains = false;
                            break;
                        }
                    }

                    if (isContains)
                    {
                        globalClass.Column1 = reader[2].ToString();
                        globalClass.Column2 = reader[4].ToString();
                        globalClass.Column3 = reader[7].ToString();
                        collGlobalClass.Add(globalClass);
                    }
                }
            nextloop: ;
            }
            catch
            {
                collGlobalClass = new Collection<GlobalClass>();
            }
            finally
            {
                conn.Close();
            }

            return collGlobalClass;
        }
    }
}
