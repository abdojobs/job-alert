﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoring_Error_Job_DB_Rep
{
    public class GlobalClass
    {
        private string _column1;
        private string _column2;
        private string _column3;
        private string _column4;
        private string _column5;

        public string Column1
        {
            get
            {
                return _column1;
            }
            set
            {
                _column1 = value;
            }
        }

        public string Column2
        {
            get
            {
                return _column2;
            }
            set
            {
                _column2 = value;
            }
        }

        public string Column3
        {
            get
            {
                return _column3;
            }
            set
            {
                _column3 = value;
            }
        }

        public string Column4
        {
            get
            {
                return _column4;
            }
            set
            {
                _column4 = value;
            }
        }

        public string Column5
        {
            get
            {
                return _column5;
            }
            set
            {
                _column5 = value;
            }
        }
    }
}
