﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoring_Error_Job_DB_Rep
{
    public class RepClass
    {
        private string _tabelName;
        private DateTime _lastUpdateTime;

        public string TabelName
        {
            get
            {
                return _tabelName;
            }
            set
            {
                _tabelName = value;
            }
        }

        public DateTime LastUpdateTime
        {
            get
            {
                return _lastUpdateTime;
            }
            set
            {
                _lastUpdateTime = value;
            }
        }
    }
}
