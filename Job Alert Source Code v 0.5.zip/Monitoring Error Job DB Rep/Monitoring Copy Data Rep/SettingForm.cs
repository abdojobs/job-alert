﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using JobAlert;
using System.Collections.ObjectModel;
namespace Monitoring_Error_Job_DB_Rep
{
    public partial class SettingForm : Form
    {
        public SettingForm()
        {
            InitializeComponent();
        }

        private void btnSaveFrom_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtFrom.Text))
            {
                string fileName = "FromText.txt";
                JobAlert.JobAlert.SaveDataTxt(fileName, txtFrom.Text); 
            }

            if (!string.IsNullOrEmpty(txtSubject.Text))
            {
                string fileName = "SubjectText.txt";
                JobAlert.JobAlert.SaveDataTxt(fileName, txtSubject.Text); 
            }

            if (!string.IsNullOrEmpty(txtSMTP.Text))
            {
                string fileName = "EmailSetting.txt";
                JobAlert.JobAlert.SaveDataTxt(fileName, txtSMTP.Text);
            }

            MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void SettingForm_Load(object sender, EventArgs e)
        {
            LoadFromText();
            LoadToText();
            LoadCCText();
            LoadSubjectText();
            LoadHeaderText();
            LoadFooterText();
            LoadModulText();
            //LoadMappingText();
            LoadExceptionText();
            LoadJobNameText();
            LoadConnection();
            LoadEmailSettingText();
        }

        private void LoadFromText()
        {
            string fileName = "FromText.txt";
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            txtFrom.Text = myText[0];
        }

        private void LoadSubjectText()
        {
            string fileName = "SubjectText.txt";
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            txtSubject.Text = myText[0];
        }

        private void LoadEmailSettingText()
        {
            string fileName = "EmailSetting.txt";
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            txtSMTP.Text = myText[0];
        }

        private void LoadHeaderText()
        {
            string fileName = "Note Header.txt";
            txtHeader.Text = JobAlert.JobAlert.LoadDataTxtString(fileName);
        }

        private void LoadFooterText()
        {
            string fileName = "NoteFooter.txt";
            txtFooter.Text = JobAlert.JobAlert.LoadDataTxtString(fileName);
        }

        private void LoadToText()
        {
            string fileName = "ToText.txt";
            cblistBoxTo.Items.Clear();
            cbEmailTo.Items.Clear();
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {
                    cblistBoxTo.Items.Add(myText[i]);
                    cbEmailTo.Items.Add(myText[i]);
                }
            }
        }

        private void LoadCCText()
        {
            string fileName = "CCText.txt";
            cListBoxCC.Items.Clear();
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {

                    cListBoxCC.Items.Add(myText[i]);
                }
            }
        }

        private void LoadModulText()
        {
            string fileName = "Modul.txt";

            clistboxModul.Items.Clear();
            clistboxLeft.Items.Clear();
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {
                    clistboxModul.Items.Add(myText[i]);
                    clistboxLeft.Items.Add(myText[i]);
                }
            }
        }

        private void LoadMappingText()
        {
            string fileName = "MappingTo.txt";
            clistBoxRight.Items.Clear();
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                string[] myMapping = myText[i].Split('-');
                if (!string.IsNullOrEmpty(myText[i]) && myMapping[0] == cbEmailTo.SelectedItem.ToString())
                {
                    for (int j = 1; j < myMapping.Length; j++)
                    {
                        clistBoxRight.Items.Add(myMapping[j]);
                    }
                }
            }
        }

        private void LoadExceptionText()
        {
            string fileName = "Exception.txt";
            clistboxException.Items.Clear();
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {
                    clistboxException.Items.Add(myText[i]);
                }
            }
        }

        private void LoadJobNameText()
        {
            string fileName = "JobName.txt";

            clistboxJobName.Items.Clear();
            string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
            for (int i = 0; i < myText.Length; i++)
            {
                if (!string.IsNullOrEmpty(myText[i]))
                {
                    clistboxJobName.Items.Add(myText[i]);
                }
            }
        }

        private void LoadConnection()
        {
            try
            {
                string fileName = "ConnectionText.txt";
                string[] myText = JobAlert.JobAlert.LoadDataTxtString(fileName, "\r\n");
                txtServerName.Text = myText[0];
                cbAuthentication.SelectedItem = myText[1];
                if (myText.Length > 4)
                {
                    txtlogin.Text = myText[2];
                    txtpassword.Text = myText[3];
                }
            }
            catch 
            {
            }
        }

        private void btnSaveTo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTo.Text))
            {
                string fileName = "ToText.txt";
                Collection<string> collData = new Collection<string>();
                for (int i = 0; i < cblistBoxTo.Items.Count; i++)
                {
                    collData.Add(cblistBoxTo.Items[i].ToString());
                }

                JobAlert.JobAlert.SaveDataTxt(fileName, txtTo.Text, collData);

                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadToText();

            }
        }

        private void btnDeleteTo_Click(object sender, EventArgs e)
        {
            bool isChecked = false;
            string fileName = "ToText.txt";
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamWriter sw = new StreamWriter(fullPathFile))
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < cblistBoxTo.Items.Count; i++)
                {
                    for (int j = 0; j < cblistBoxTo.CheckedItems.Count; j++)
                    {
                        if (cblistBoxTo.Items[i] == cblistBoxTo.CheckedItems[j])
                        {
                            isChecked = true;
                            break;
                        }
                    }
                    if (!isChecked)
                    {
                        sb.AppendLine(cblistBoxTo.Items[i].ToString());

                    }

                    isChecked = false;
                }
                sw.WriteLine(sb.ToString());
                sw.Close();

                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadToText();
            }

        }

        private void btnSaveCC_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCC.Text))
            {
                string fileName = "CCText.txt";

                Collection<string> collData = new Collection<string>();
                for (int i = 0; i < cListBoxCC.Items.Count; i++)
                {
                    collData.Add(cListBoxCC.Items[i].ToString());
                }

                JobAlert.JobAlert.SaveDataTxt(fileName, txtCC.Text, collData);
                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadCCText();
            }
        }

        private void btnDeleteCC_Click(object sender, EventArgs e)
        {
            bool isChecked = false;
            string fileName = "CCText.txt";
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamWriter sw = new StreamWriter(fullPathFile))
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < cListBoxCC.Items.Count; i++)
                {
                    for (int j = 0; j < cListBoxCC.CheckedItems.Count; j++)
                    {
                        if (cListBoxCC.Items[i] == cListBoxCC.CheckedItems[j])
                        {
                            isChecked = true;
                            break;
                        }
                    }
                    if (!isChecked)
                    {
                        sb.AppendLine(cListBoxCC.Items[i].ToString());

                    }

                    isChecked = false;
                }
                sw.WriteLine(sb.ToString());
                sw.Close();

                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadCCText();
            }
        }

        private void btnSaveHeader_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSubject.Text))
            {
                string fileName = "Note Header.txt";
                JobAlert.JobAlert.SaveDataTxt(fileName, txtHeader.Text); 
            }

            MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSaveFooter_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtFooter.Text))
            {
                string fileName = "NoteFooter.txt";
                JobAlert.JobAlert.SaveDataTxt(fileName, txtFooter.Text); 
            }

            MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSaveModul_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtModul.Text))
            {
                string fileName = "Modul.txt";

                Collection<string> collData = new Collection<string>();
                for (int i = 0; i < clistboxModul.Items.Count; i++)
                {
                    collData.Add(clistboxModul.Items[i].ToString());
                }

                JobAlert.JobAlert.SaveDataTxt(fileName, txtModul.Text, collData);
                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadModulText();

            }
        }

        private void btnDeleteModul_Click(object sender, EventArgs e)
        {
            bool isChecked = false;
            string fileName = "Modul.txt";
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamWriter sw = new StreamWriter(fullPathFile))
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < clistboxModul.Items.Count; i++)
                {
                    for (int j = 0; j < clistboxModul.CheckedItems.Count; j++)
                    {
                        if (clistboxModul.Items[i] == clistboxModul.CheckedItems[j])
                        {
                            isChecked = true;
                            break;
                        }
                    }
                    if (!isChecked)
                    {
                        sb.AppendLine(clistboxModul.Items[i].ToString());

                    }

                    isChecked = false;
                }
                sw.WriteLine(sb.ToString());
                sw.Close();

                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadModulText();
            }
        }

        private void cbEmailTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadMappingText();
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < clistboxLeft.CheckedItems.Count; i++)
            {
                if ( !clistBoxRight.Items.Contains(clistboxLeft.CheckedItems[i]))
                {
                    clistBoxRight.Items.Add(clistboxLeft.CheckedItems[i]);
                }
            }
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < clistBoxRight.Items.Count; i++)
            {
                for (int j = 0; j < clistBoxRight.CheckedItems.Count; j++)
                {
                    if (clistBoxRight.Items[i] == clistBoxRight.CheckedItems[j])
                    {
                        clistBoxRight.Items.RemoveAt(i);
                        i = -1;
                        break;
                    }
                }
            }
        }

        private void btnSaveMappingTo_Click(object sender, EventArgs e)
        {
            string dataSave = string.Empty;
            string dataTxt = string.Empty;
            string fileName = "MappingTo.txt";
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamReader sr = new StreamReader(fullPathFile))
            {
                dataTxt = sr.ReadToEnd();
                if (dataTxt.Contains(cbEmailTo.SelectedItem.ToString()))
                {
                    string[] myText = dataTxt.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                    for (int i = 0; i < myText.Length; i++)
                    {
                        if (myText[i] != "\r\n")
                        {
                            if (!string.IsNullOrEmpty(myText[i]))
                            {
                                string newData = string.Empty;
                                string[] myMapping = myText[i].Split('-');
                                if (myMapping[0] == cbEmailTo.SelectedItem.ToString())
                                {
                                    newData = cbEmailTo.SelectedItem.ToString() + "-";
                                    for (int j = 0; j < clistBoxRight.Items.Count; j++)
                                    {
                                        newData += clistBoxRight.Items[j];
                                        if (j != clistBoxRight.Items.Count - 1)
                                        {
                                            newData += "-";
                                        }
                                    }
                                    dataSave += newData + "\r\n";
                                }
                                else
                                {
                                    dataSave += myText[i] + "\r\n";
                                }
                            }
                        }
                    }
                }
                else
                {
                    dataSave = dataTxt;
                    string newData = string.Empty;
                    newData = cbEmailTo.SelectedItem.ToString() + "-";
                    for (int j = 0; j < clistBoxRight.Items.Count; j++)
                    {
                        newData += clistBoxRight.Items[j];
                        if (j != clistBoxRight.Items.Count - 1)
                        {
                            newData += "-";
                        }
                    }
                    dataSave += newData + "\r\n";

                }
            }

            using (StreamWriter sw = new StreamWriter(fullPathFile))
            {
                StringBuilder sb = new StringBuilder();
                sw.Write(dataSave);
                sw.Close();

                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSaveException_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtException.Text))
            {
                string fileName = "Exception.txt";
                Collection<string> collData = new Collection<string>();
                for (int i = 0; i < clistboxException.Items.Count; i++)
                {
                    collData.Add(clistboxException.Items[i].ToString());
                }

                JobAlert.JobAlert.SaveDataTxt(fileName, txtException.Text, collData);

                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadExceptionText();

            }
        }

        private void btnDeleteException_Click(object sender, EventArgs e)
        {
            bool isChecked = false;
            string fileName = "Exception.txt";
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamWriter sw = new StreamWriter(fullPathFile))
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < clistboxException.Items.Count; i++)
                {
                    for (int j = 0; j < clistboxException.CheckedItems.Count; j++)
                    {
                        if (clistboxException.Items[i] == clistboxException.CheckedItems[j])
                        {
                            isChecked = true;
                            break;
                        }
                    }
                    if (!isChecked)
                    {
                        sb.AppendLine(clistboxException.Items[i].ToString());

                    }

                    isChecked = false;
                }
                sw.WriteLine(sb.ToString());
                sw.Close();

                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadExceptionText();
            }
        }

        private void btnSaveJobName_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtJobName.Text))
            {
                string fileName = "JobName.txt";
                Collection<string> collData = new Collection<string>();
                for (int i = 0; i < clistboxJobName.Items.Count; i++)
                {
                    collData.Add(clistboxJobName.Items[i].ToString());
                }

                JobAlert.JobAlert.SaveDataTxt(fileName, txtJobName.Text, collData);
                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadJobNameText();

            }
        }

        private void btnDeleteJobName_Click(object sender, EventArgs e)
        {
            bool isChecked = false;
            string fileName = "JobName.txt";
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            using (StreamWriter sw = new StreamWriter(fullPathFile))
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < clistboxJobName.Items.Count; i++)
                {
                    for (int j = 0; j < clistboxJobName.CheckedItems.Count; j++)
                    {
                        if (clistboxJobName.Items[i] == clistboxJobName.CheckedItems[j])
                        {
                            isChecked = true;
                            break;
                        }
                    }
                    if (!isChecked)
                    {
                        sb.AppendLine(clistboxJobName.Items[i].ToString());

                    }

                    isChecked = false;
                }
                sw.WriteLine(sb.ToString());
                sw.Close();

                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadJobNameText();
            }
        }

        private void cbAuthentication_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbAuthentication.SelectedItem.Equals("SQL Server Authentication"))
            {
                txtlogin.Enabled = true;
                txtpassword.Enabled = true;
            }
            else
            {
                txtlogin.Enabled = false;
                txtpassword.Enabled = false;
            }
        }

        private void btnSaveConnection_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            string fileName = "ConnectionText.txt";
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "Config");
            string fullPathFile = Path.Combine(path, fileName);
            if (!string.IsNullOrEmpty(txtServerName.Text))
            {
                if (!string.IsNullOrEmpty(cbAuthentication.SelectedItem.ToString()))
                {
                    if (cbAuthentication.SelectedItem.Equals("SQL Server Authentication"))
                    {
                        if (!string.IsNullOrEmpty(txtlogin.Text))
                        {
                            if (!string.IsNullOrEmpty(txtpassword.Text))
                            {
                                sb.AppendLine(txtServerName.Text);
                                sb.AppendLine(cbAuthentication.SelectedItem.ToString());
                                sb.AppendLine(txtlogin.Text);
                                sb.AppendLine(txtpassword.Text);
                                sb.AppendLine("Server=" + txtServerName.Text + ";Database=msdb;uid=" + txtlogin.Text + ";Password=" + txtpassword.Text);
                                JobAlert.JobAlert.SaveDataTxt(fileName, sb.ToString());
                                MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            }
                            else
                            {
                                MessageBox.Show("Password Please", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                        else
                        {
                            MessageBox.Show("User Name Please", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        sb.AppendLine(txtServerName.Text);
                        sb.AppendLine(cbAuthentication.SelectedItem.ToString());
                        sb.AppendLine("Server=" + txtServerName.Text + ";Initial Catalog=msdb;Integrated Security = True");
                        JobAlert.JobAlert.SaveDataTxt(fileName, sb.ToString());
                        MessageBox.Show("Save Success", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
                else
                {
                    MessageBox.Show("Authentication Please", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Server Name Please", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
