﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monitoring_Error_Job_DB_Rep
{
    public class EquipmentColorClass
    {
        private string _equipmentNo;
        private string _color;

        public string EquipmentNo
        {
            get
            {
                return _equipmentNo;
            }
            set
            {
                _equipmentNo = value;
            }
        }

        public string Color
        {
            get
            {
                return string.IsNullOrEmpty(_color) ? string.Empty : _color;
            }
            set
            {
                _color = value;
            }
        }
    }
}
