﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Net.Mail;
using System.IO;
using JobAlert;
using System.Diagnostics;

namespace Monitoring_Error_Job_DB_Rep
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
                                 
        private void btnExec_Click(object sender, EventArgs e)
        {
            JobAlert.JobAlert.PopulateJobAlert();

            CheckIsLastDay();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int totalDetik = int.Parse(label1.Text);
            int menitAll = totalDetik / 60;
            int jam = totalDetik / 3600;
            int menit = menitAll % 60;
            int detik = totalDetik % 60;

            label1.Text = "" + (totalDetik - 1);
            label3.Text = (jam.ToString().Length == 1 ? "0" + jam.ToString() : jam.ToString()) + ":" +
                (menit.ToString().Length == 1 ? "0" + menit.ToString() : menit.ToString()) + ":" +
                (detik.ToString().Length == 1 ? "0" + detik.ToString() : detik.ToString());

            if (int.Parse(label1.Text) == 0)
            {
                btnExec_Click(sender, e);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CheckIsLastDay();
        }

        private void CheckIsLastDay()
        {
            int totalDetik;
            int menitAll;
            int jam;
            int menit;
            int detik;
            label1.Text = "14400"; //4 jam 

            if (DateTime.Now.AddDays(1).Day.Equals(1) || DateTime.Now.Day.Equals(1))
            {
                label1.Text = "7200"; //2jam 
            }

            totalDetik = int.Parse(label1.Text);
            menitAll = totalDetik / 60;
            jam = totalDetik / 3600;
            menit = menitAll % 60;
            detik = totalDetik % 60;

            label3.Text = (jam.ToString().Length == 1 ? "0" + jam.ToString() : jam.ToString()) + ":" +
            (menit.ToString().Length == 1 ? "0" + menit.ToString() : menit.ToString()) + ":" +
            (detik.ToString().Length == 1 ? "0" + detik.ToString() : detik.ToString());
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            SettingForm sf = new SettingForm();
            sf.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start("mailto:fero.chandra@gmail.com?subject:Any Question");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
